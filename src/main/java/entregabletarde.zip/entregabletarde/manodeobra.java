package entregabletarde;

public class manodeobra {
    private String nombredeempresa;
    private String descripciontrabajo;
    private int horasrealizadas;
    private int obrerosimplicados;

    public manodeobra(String nombredeempresa, String descripciontrabajo, int horasrealizadas, int obrerosimplicados){
        this.nombredeempresa=nombredeempresa;
        this.descripciontrabajo=descripciontrabajo;
        this.horasrealizadas= horasrealizadas;
        this.obrerosimplicados=obrerosimplicados;

    }
}
