package entregabletarde;

import java.util.Scanner;

public class MAIN {
  public static void main(String[] args) {
      Scanner teclado= new Scanner(System.in);
      material m1 = new material("la roca es dura","Rocas.SL",25,2,3);
      vivienda v1= new vivienda("c/Cristiano Ronaldo",25);


  }
}
